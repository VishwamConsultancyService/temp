import express from "express";
import invokeRouter from "./routes/invoke";
import revokeRouter from "./routes/revoke";

const app = express();
app.use(express.json());

app.use("/invoke", invokeRouter);
app.use("/revoke", revokeRouter);

export default app;
