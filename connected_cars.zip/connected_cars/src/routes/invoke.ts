import express from "express";
import { getAccessToken } from "../services/authService";
import { sendSoapRequest } from "../services/soapService";

const router = express.Router();

router.get("/", async (req: any, res: any) => {
  try {
    const authResult = await getAccessToken();
    if (!authResult) {
      return res.status(401).json({ error: "Authentication failed" });
    }

    const { access_token, serviceUrl } = authResult;
    
    let matsResponse;
    try {
      matsResponse = await sendSoapRequest(serviceUrl, "mats_create.xml", access_token, req.body.msisdn);
    } catch (matsError) {
      console.error("MATS request failed:", matsError);
      return res.status(500).json({ error: "mats failed" });
    }

    let enumResponse;
    try {
      enumResponse = await sendSoapRequest(serviceUrl, "enum_create.xml", access_token, req.body.msisdn);
    } catch (enumError) {
      console.error("ENUM request failed:", enumError);
      return res.status(500).json({ matsResponse, error: "enum failed" });
    }

    res.json({ matsResponse, enumResponse });
  } catch (error) {
    console.error("Invoke request failed:", error);
    res.status(500).json({ error: "Failed to process invoke request" });
  }
});

export default router;
