import express from "express";
import { getAccessToken } from "../services/authService";
import { sendSoapRequest } from "../services/soapService";

const router = express.Router();

router.get("/", async (req: any, res: any) => {
  try {
    const authResult = await getAccessToken();
    if (!authResult) {
      return res.status(401).json({ error: "Authentication failed" });
    }

    const { access_token, serviceUrl } = authResult;

    // Call mats_create and enum_create using the correct service URL
    const matsResponse = await sendSoapRequest(
      serviceUrl, // Pass correct service URL
      "mats_create.xml",
      access_token,
      req.body.msisdn
    );
    
    const enumResponse = await sendSoapRequest(
      serviceUrl, // Pass correct service URL
      "enum_create.xml",
      access_token,
      req.body.msisdn
    );

    res.json({ matsResponse, enumResponse });
  } catch (error) {
    console.error("Invoke request failed:", error);
    res.status(500).json({ error: "Failed to process invoke request" });
  }
});

export default router;
