import express from "express";
import bodyParser from "body-parser";
import axios from "axios"; // To make internal requests

const app = express();
const PORT = 5002; // Mock server runs on port 5002

app.use(bodyParser.json());

// Simulating OAuth token responses
app.post("/service1/oauth/token", (req, res) => {
  console.log("Mock Service 1 token request received.");
  res.json({ access_token: "mock_service1_token" });
});

app.post("/service2/oauth/token", (req, res) => {
  console.log("Mock Service 2 token request received.");
  res.json({ access_token: "mock_service2_token" });
});

// Internal function to simulate SOAP calls
const callSoapService = async (url: string) => {
  try {
    const response = await axios.post(url, {}, { headers: { "Content-Type": "text/xml" } });
    return response.data;
  } catch (error) {
    console.error(`Error calling ${url}:`, error);
    return `Failed: ${url}`;
  }
};

// SOAP Invoke (calls mats_create & enum_create)
app.post("/service1/soap/invoke", async (req, res) => {
  console.log("Mock SOAP INVOKE request received.");

  const matsResponse = await callSoapService(`http://localhost:${PORT}/service1/mats_create`);
  const enumResponse = await callSoapService(`http://localhost:${PORT}/service1/enum_create`);

  res.json({ matsResponse, enumResponse });
});

// SOAP Revoke (calls mats_delete & enum_delete)
app.post("/service1/soap/revoke", async (req, res) => {
  console.log("Mock SOAP REVOKE request received.");

  const matsResponse = await callSoapService(`http://localhost:${PORT}/service1/mats_delete`);
  const enumResponse = await callSoapService(`http://localhost:${PORT}/service1/enum_delete`);

  res.json({ matsResponse, enumResponse });
});

// Simulating SOAP responses for service1
app.post("/service1/mats_create", (req, res) => {
  console.log("Mock MATS CREATE request received.");
  res.set("Content-Type", "text/xml");
  res.send(`<soap:Envelope><soap:Body><Response>MATS Create Success</Response></soap:Body></soap:Envelope>`);
});

app.post("/service1/enum_create", (req, res) => {
  console.log("Mock ENUM CREATE request received.");
  res.set("Content-Type", "text/xml");
  res.send(`<soap:Envelope><soap:Body><Response>ENUM Create Success</Response></soap:Body></soap:Envelope>`);
});

app.post("/service1/mats_delete", (req, res) => {
  console.log("Mock MATS DELETE request received.");
  res.set("Content-Type", "text/xml");
  res.send(`<soap:Envelope><soap:Body><Response>MATS Delete Success</Response></soap:Body></soap:Envelope>`);
});

app.post("/service1/enum_delete", (req, res) => {
  console.log("Mock ENUM DELETE request received.");
  res.set("Content-Type", "text/xml");
  res.send(`<soap:Envelope><soap:Body><Response>ENUM Delete Success</Response></soap:Body></soap:Envelope>`);
});

// Start the mock server
app.listen(PORT, () => {
  console.log(`✅ Mock server running at http://localhost:${PORT}`);
});
