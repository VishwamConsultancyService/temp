import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

interface AuthResult {
  access_token: string;
  serviceUrl: string;
}

const getAccessToken = async (): Promise<AuthResult | null> => {
  try {
    // Try Service 1
    let response = await axios.post(`${process.env.SERVICE1_URL}/oauth/token`, {
      client_id: process.env.SERVICE1_CLIENT_ID,
      client_secret: process.env.SERVICE1_CLIENT_SECRET,
      grant_type: "client_credentials",
    });
    
    if (response.data.access_token) {
      console.log("Authenticated via Service 1");
      return { access_token: response.data.access_token, serviceUrl: process.env.SERVICE1_URL! };
    }
  } catch (error) {
    console.log(`${process.env.SERVICE1_URL}/oauth/token`);
    console.log("Service 1 authentication failed, trying Service 2...");
  }

  try {
    // Try Service 2
    let response = await axios.post(`${process.env.SERVICE2_URL}/oauth/token`, {
      client_id: process.env.SERVICE2_CLIENT_ID,
      client_secret: process.env.SERVICE2_CLIENT_SECRET,
      grant_type: "client_credentials",
    });

    if (response.data.access_token) {
      console.log("Authenticated via Service 2");
      return { access_token: response.data.access_token, serviceUrl: process.env.SERVICE2_URL! };
    }
  } catch (error) {
    console.log(`${process.env.SERVICE2_URL}/oauth/token`);
    console.error("Both authentication attempts failed");
  }

  return null;
};

export { getAccessToken };
