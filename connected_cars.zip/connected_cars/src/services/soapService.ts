import fs from "fs";
import path from "path";  // Import path module
import axios from "axios";
import { parseStringPromise, Builder } from "xml2js";

const sendSoapRequest = async (
  serviceUrl: string, // Dynamically use the correct service URL
  fileName: string,
  accessToken: string,
  msisdn: string
): Promise<any> => {
  try {
    // Construct the absolute file path
    const filePath = path.resolve(__dirname, "../payloads", fileName);
    console.log("Using SOAP file:", filePath); // Debugging log

    // Read the SOAP XML template
    const xmlTemplate = fs.readFileSync(filePath, "utf8");

    // Parse XML to JSON
    const jsonTemplate = await parseStringPromise(xmlTemplate);

    // Modify the XML with dynamic values
    // jsonTemplate["soap:Envelope"]["soap:Body"][0]["yourSOAPMethod"][0]["yourParam"][0] = value.msisdn;

    // Convert back to XML
    const builder = new Builder();
    const modifiedXml = builder.buildObject(jsonTemplate);

    // Make the SOAP request to the correct service URL
    const response = await axios.post(`${serviceUrl}/soap/invoke`, modifiedXml, {
      headers: {
        "Content-Type": "text/xml",
        Authorization: `Bearer ${accessToken}`,
      },
    });

    return response.data;
  } catch (error) {
    console.error("SOAP request failed:", error);
    throw error;
  }
};

export { sendSoapRequest };
